﻿using UnityEngine;
using System.Collections;

public abstract class BaseAi : MonoBehaviour {

	// Use this for initialization
	[SerializeField] protected float visionDist = 0;

	[SerializeField] protected BaseShip ship;
	[SerializeField] protected SphereCollider visionCollider = null;
	public virtual void Start () 
	{
		if( ship == null)
		{
			Debug.Log(this.name + " needs a ship script assigned");
		}

		if( visionCollider != null)
			visionCollider.radius = visionDist;
		else
			Debug.Log("Ship " + this.name + " needs a vision sphere assigned");

		if( this.gameObject.layer != 12)
		{
			this.gameObject.layer = 12;
		}
	}

	public virtual void AIUpdate()
	{

	}

	public virtual void EnteredVisionSphere(Collider collider)
	{

	}

	public virtual void OnTriggerEnter(Collider collider)
	{
		EnteredVisionSphere(collider);
	}

	public void Update () 
	{
		AIUpdate();
	}

}
