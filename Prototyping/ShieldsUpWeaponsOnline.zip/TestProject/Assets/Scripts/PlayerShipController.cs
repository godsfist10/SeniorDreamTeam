﻿using UnityEngine;
using System.Collections;

public class PlayerShipController : MonoBehaviour {
	
	[SerializeField] private BaseShip ship;

	void Start()
	{
		if( ship == null)
		{
			Debug.Log(this.name + " needs a ship script assigned");
		}

		if( this.gameObject.layer != 12)
			this.gameObject.layer = 12;
	}

	void Update ()
	{
		if (Input.GetKey (KeyCode.W)) 
		{
			ship.Accelerate();
		}
		if( Input.GetKey(KeyCode.S))
		{
			ship.Deaccelerate();
		}

		if( Input.GetKeyDown(KeyCode.LeftShift))
		{
			ship.startBoost();
		}
		if( Input.GetKeyUp(KeyCode.LeftShift))
		{
			ship.endBoost();
		}

		if(Input.GetMouseButton(0))
		{
			ship.FireWeapon();
		}

		float roll = 0;
		float pitch = 0;
		float yaw = 0;
		roll = Input.GetAxis("Roll") * (Time.fixedDeltaTime);
		pitch = Input.GetAxis("Pitch") * (Time.fixedDeltaTime);
		yaw = Input.GetAxis("Yaw") * (Time.fixedDeltaTime);
		ship.controlRotation (roll, pitch, yaw);

	}
}
